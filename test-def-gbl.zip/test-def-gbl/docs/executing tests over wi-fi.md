Executing Test-Scripts Over WiFi
================================

1. Connect device to computer via USB. 
2. Make sure device and computer are connected to the same Wi-Fi.
3. Run below command to restart adb and make it work over tcpip...

		adb tcpip 5555

4. Disconnect the device
5. Get IP address of your phone ("Settings" -> Wifi -> “Your connected WiFi network” -> Your IP address")
6. Run below command to connect adb to your device over Wi-Fi using IP address:

		adb connect <your phones ip address>		

7. To verify that adb works remotely run below command...
   This should show <your phones ip address>:5555 device under List of devices attached

		adb devices

8. Update 'androidCapabilities:' in input-data.yaml
		
    deviceName: "<your phones ip address>:5555"

9. Execute tests over Wi-Fi!
